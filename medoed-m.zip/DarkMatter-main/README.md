# Dark Matter
A cold, dark & frosty theme.
> This is a remake of the original Dark Matter theme by [cosmicsalad](http://github.com/cosmicsalad/) (AKA Hammock).

![Preview](https://i.imgur.com/xSG96qa.png)

## Credits
* Hammock for making the original theme.
* Devilbro for giving me permission to use his BlurpleRecolor theme. This saved a lot of time.
